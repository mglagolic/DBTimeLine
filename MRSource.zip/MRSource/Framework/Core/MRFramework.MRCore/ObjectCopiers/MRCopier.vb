﻿Public MustInherit Class MRCopier(Of T)

    Public MustOverride Function Copy(obj As Object) As Object

End Class
