﻿
Public Interface IMROrderItem
    Property ColumnName As String
    Property Direction As MRCore.Enums.eOrderDirection
End Interface
