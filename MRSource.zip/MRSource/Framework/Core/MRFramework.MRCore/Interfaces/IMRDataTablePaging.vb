﻿Imports System.ComponentModel
Public Interface IMRDataTablePaging
    Inherits IMRDataPaging
    Inherits IMRDatatable
    Inherits IDisposable

End Interface
