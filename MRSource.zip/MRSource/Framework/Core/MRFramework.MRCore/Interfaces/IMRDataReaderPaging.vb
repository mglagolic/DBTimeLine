﻿Public Interface IMRDataReaderPaging
    Inherits IMRDataPaging
    Inherits IDisposable

End Interface
