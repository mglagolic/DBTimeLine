﻿Namespace Enums
    Public Module Enums
        

        'Public Enum eDataFieldAttributeTypes
        '    Readable = 0
        '    Writable = 1
        '    IsIdentity = 2
        'End Enum


        Public Enum eOrderDirection
            Ascending
            Descending
        End Enum

        'Public Enum eBLLState
        '    Unchanged = 0
        '    Added = 1
        '    Modified = 2
        'End Enum
    End Module

End Namespace