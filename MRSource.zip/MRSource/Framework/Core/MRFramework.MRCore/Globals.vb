﻿Public Class Globals

    Public Const PagingEnabled As Boolean = True
    Public Const PageSize As Integer = 10
    Public Const SYS_GUID As String = "SYS_GUID"
    'Public Const IncludeRowNumInQueries As Boolean = True

    'Public Enum eToolStipAction
    '    None = 0
    '    Cancel = 1
    '    Add = 2
    '    Edit = 3
    '    Save = 4
    '    Delete = 5
    '    MoveFirst = 6
    '    MovePrevious = 7
    '    MoveNext = 8
    '    MoveLast = 9
    'End Enum
End Class
