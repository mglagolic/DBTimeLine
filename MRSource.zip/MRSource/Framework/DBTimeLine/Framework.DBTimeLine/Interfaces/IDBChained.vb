﻿Public Interface IDBChained
    Property Parent As IDBChained
End Interface
