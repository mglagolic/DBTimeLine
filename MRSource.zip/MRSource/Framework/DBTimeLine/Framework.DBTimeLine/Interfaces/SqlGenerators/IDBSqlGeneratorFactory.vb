﻿Public Interface IDBSqlGeneratorFactory

    Function GetDBSqlGenerator(dbType As eDBType) As IDBSqlGenerator

End Interface
