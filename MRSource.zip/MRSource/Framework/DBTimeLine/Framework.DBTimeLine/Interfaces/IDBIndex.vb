﻿Public Interface IDBIndex
    Inherits IDBObject

End Interface