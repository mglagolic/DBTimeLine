﻿Public Interface IDBConstraint
    Inherits IDBObject

End Interface