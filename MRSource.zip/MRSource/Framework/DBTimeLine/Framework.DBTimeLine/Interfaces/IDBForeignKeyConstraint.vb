﻿Public Interface IDBForeignKeyConstraint
    Inherits IDBConstraint

End Interface