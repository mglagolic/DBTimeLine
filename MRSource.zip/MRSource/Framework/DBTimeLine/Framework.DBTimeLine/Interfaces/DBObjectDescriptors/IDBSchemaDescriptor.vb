﻿Public Interface IDBSchemaDescriptor
    Inherits IDBObjectDescriptor

End Interface