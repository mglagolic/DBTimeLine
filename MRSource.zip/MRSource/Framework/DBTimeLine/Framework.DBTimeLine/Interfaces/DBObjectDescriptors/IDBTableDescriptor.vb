﻿Public Interface IDBTableDescriptor
    Inherits IDBObjectDescriptor

    Property CreatorFieldName As String
    Property CreatorFieldDescriptor As IDBFieldDescriptor

End Interface