﻿Public Interface IDBViewDescriptor
    Inherits IDBObjectDescriptor

    Property WithSchemaBinding As Boolean
    Property Body As String

End Interface
