﻿Public Interface IDBObjectDescriptor
    Function GetDBObjectInstance(Optional parent As IDBChained = Nothing) As IDBObject
End Interface
