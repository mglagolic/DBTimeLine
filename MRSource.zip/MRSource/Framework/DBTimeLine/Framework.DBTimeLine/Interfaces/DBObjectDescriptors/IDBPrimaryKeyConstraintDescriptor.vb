﻿Public Interface IDBPrimaryKeyConstraintDescriptor
    Inherits IDBConstraintDescriptor

    ReadOnly Property Columns As List(Of String)
End Interface