﻿Public Interface IDBPrimaryKeyConstraint
    Inherits IDBConstraint

End Interface