﻿Public Enum eDBRevisionType
    Create = 0
    Modify = 1
    Delete = 2
    AlwaysExecuteTask = 3
    Task = 4
End Enum