﻿Public Enum eBatchExecutionResultType
    Success = 0
    Warning = 1
    Failed = 2
End Enum