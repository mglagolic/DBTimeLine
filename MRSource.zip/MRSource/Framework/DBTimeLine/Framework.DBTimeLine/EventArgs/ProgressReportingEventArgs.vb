﻿Public Class ProgressReportedEventArgs
    Inherits EventArgs

    Public Property Message As String
    Public Property CurrentStep As Integer
    Public Property TotalSteps As Integer
End Class


