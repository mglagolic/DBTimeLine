﻿Public Class ModuleLoadedEventArgs
    Inherits EventArgs

    Public Property Message As String
    Public Property ErrorMessage As String

End Class
