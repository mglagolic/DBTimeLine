﻿Public Class DBSqlGeneratorSqlServer
    Inherits DBSqlGenerator

    Public Sub New()
        MyBase.New
    End Sub

End Class
