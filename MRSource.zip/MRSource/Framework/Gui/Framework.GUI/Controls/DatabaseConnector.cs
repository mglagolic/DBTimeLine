﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Framework.GUI.Controls
{
    public partial class DatabaseConnector : UserControl
    {
        public DatabaseConnector()
        {
            InitializeComponent();
        }
        
        private void btnRefreshServer_Click(object sender, EventArgs e)
        {

        }

        private void btnRefreshDB_Click(object sender, EventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {

        }
    }
}
