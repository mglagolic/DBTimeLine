﻿Public Class MRSaveData

    Public Shared Sub Update(ByVal ds As DataSet)
        Try

        Catch ex As Exception

        End Try
    End Sub

End Class
