﻿Public Interface IMRDeleteDLOReturnValue
    Property ConcurrentDLO As IMRDLO
    Property Result As Enums.edeleteDLOResults

End Interface
