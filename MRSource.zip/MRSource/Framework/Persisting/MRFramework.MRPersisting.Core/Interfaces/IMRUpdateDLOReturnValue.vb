﻿Public Interface IMRUpdateDLOReturnValue
    Property ConcurrentDLO As IMRDLO
    Property Result As Enums.eUpdateDLOResults

End Interface
