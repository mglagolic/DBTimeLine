﻿Public Interface IMRRowReadEventArgs
    Property RowIndex As Long
    Property Dlo As IMRDLO
End Interface
