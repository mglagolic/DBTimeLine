﻿Public Interface IMRInsertDLOReturnValue
    Property Result As Enums.eInsertDLOResults
    Property Dlo As MRPersisting.Core.IMRDLO

End Interface
