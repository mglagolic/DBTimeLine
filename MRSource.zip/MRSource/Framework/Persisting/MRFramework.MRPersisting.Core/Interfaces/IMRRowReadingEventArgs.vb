﻿Public Interface IMRRowReadingEventArgs
    Property Cancel As Boolean
    Property RowIndex As Long

End Interface
