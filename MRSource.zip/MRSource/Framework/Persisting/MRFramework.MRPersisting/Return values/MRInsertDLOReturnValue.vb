﻿Imports MRFramework.MRPersisting.Core
Public Class MRInsertDLOReturnValue
    Implements IMRInsertDLOReturnValue

    Public Property Result As Enums.eInsertDLOResults Implements IMRInsertDLOReturnValue.Result
    Public Property Dlo As MRPersisting.Core.IMRDLO Implements IMRInsertDLOReturnValue.Dlo


End Class
