﻿Imports System.Data.Common
Public Class MRDbParameterCopierOutput
    Public Property Parameter As DbParameter
End Class

