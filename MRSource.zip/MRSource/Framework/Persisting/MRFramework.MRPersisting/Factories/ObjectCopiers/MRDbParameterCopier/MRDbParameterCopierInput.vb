﻿Imports System.Data.Common
Public Class MRDbParameterCopierInput
    Public Property Parameter As DbParameter
    Public Property Command As DbCommand
End Class

