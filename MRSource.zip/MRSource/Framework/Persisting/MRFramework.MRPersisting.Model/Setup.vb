﻿Namespace Setup
    Public Module Setup
        Public Sub SetupIntances( _
                                connectionString As String, _
                                providerName As String _
                                )

            MRPersisting.Setup.SetupIntances(connectionString, providerName)

        End Sub
    End Module

End Namespace