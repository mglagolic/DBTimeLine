﻿using System.Collections.Generic;

namespace Framework.Persisting.Interfaces
{
    public interface IDatabaseConnector
    {
        string GenerateConnectionString(string serverInstanceName, string databaseName, string username = "", string password = "", int connectionTimeout = 30);
        List<string> LoadServers();
        List<string> LoadDatabases(string serverInstanceName);
        bool TestConnect(string connectionString);
    }
}
