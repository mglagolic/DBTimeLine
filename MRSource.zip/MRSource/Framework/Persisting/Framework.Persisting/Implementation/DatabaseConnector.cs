﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Framework.Persisting.Interfaces;

namespace Framework.Persisting.Implementation
{
    public class DatabaseConnector : IDatabaseConnector
    {
        public string GenerateConnectionString(string serverInstanceName, string databaseName, string username = "", string password = "", int connectionTimeout = 30)
        {
            var ret = "Data Source={0};Initial Catalog={1}{2};Connection Timeout={3}";
            var security = ";Integrated Security=True";
            if (username != "") security = string.Format(";User ID={0};Password={1}", username, password);

            return string.Format(ret, serverInstanceName, databaseName, security, connectionTimeout.ToString());
        }

        public List<string> LoadDatabases(string serverInstanceName)
        {
            throw new NotImplementedException();
        }

        private static List<string> _Servers
        {
            get; set;
        }
        public List<string> LoadServers()
        {
            throw new NotImplementedException();
        }

        public bool TestConnect(string connectionString)
        {
            throw new NotImplementedException();
        }
    }
}
