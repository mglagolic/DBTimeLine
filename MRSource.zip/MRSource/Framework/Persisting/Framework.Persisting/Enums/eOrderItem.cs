﻿namespace Framework.Persisting.Enums
{
    public enum eOrderDirection
    {
        Ascending = 0,
        Descending = 1
    }
}
