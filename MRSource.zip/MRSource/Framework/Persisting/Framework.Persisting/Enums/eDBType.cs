﻿namespace Framework.Persisting.Enums
{
    public enum eDBType
    {
        TransactSQL = 0,
        SqlServer = 1,
        MySql = 2
    }
}

