﻿namespace Customizations.Core
{
    public class Customizer
    {
        public string CustomizationKey { get; set; }
    }
}
